SMODS.Joker{ --free coupom
    name = "free coupom",
    key = "freecoupom",
    config = {
        extra = {
            left = 3,
            var1 = 0
        }
    },
    loc_txt = {
        ['name'] = 'free coupom',
        ['text'] = {
            [1] = 'halves all prices for the next #1# shops'
        }
    },
    pos = {
        x = 9,
        y = 2
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = false,
    eternal_compat = false,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.left}}
    end,

    calculate = function(self, card, context)
        if context.end_of_round and context.game_over == false and context.main_eval and not context.blueprint then
            if (card.ability.extra.var1 or 0) < 1 then
                return {
                    func = function()
                card:start_dissolve()
                return true
            end,
                    message = "expired"
                }
            else
                return {
                    func = function()
                    card.ability.extra.var1 = math.max(0, (card.ability.extra.var1) - 1)
                    return true
                end,
                    message = "#1# rounds remaining"
                }
            end
        end
    end,

    add_to_deck = function(self, card, from_debuff)
        G.E_MANAGER:add_event(Event({
    func = function()
        for k, v in pairs(G.I.CARD) do
            if v.set_cost then v:set_cost() end
        end
        return true
    end
}))
    end,

    remove_from_deck = function(self, card, from_debuff)
        G.E_MANAGER:add_event(Event({
    func = function()
        for k, v in pairs(G.I.CARD) do
            if v.set_cost then v:set_cost() end
        end
        return true
    end
}))
    end
}