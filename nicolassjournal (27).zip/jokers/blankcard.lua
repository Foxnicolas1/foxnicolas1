SMODS.Joker{ --blank card
    name = "blank card",
    key = "blankcard",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'blank card',
        ['text'] = {
            [1] = 'does nothing?'
        }
    },
    pos = {
        x = 9,
        y = 1
    },
    cost = 1,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main then
                return {
                    message = "nothing"
                }
        end
    end
}