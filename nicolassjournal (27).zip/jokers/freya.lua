SMODS.Joker{ --freya
    name = "freya",
    key = "freya",
    config = {
        extra = {
            jokercount = 1
        }
    },
    loc_txt = {
        ['name'] = 'freya',
        ['text'] = {
            [1] = 'grants {X:chips,C:white}x1.5{} per joker you have',
            [2] = '(currently {X:chips,C:white}x#1#{} Chips)'
        }
    },
    pos = {
        x = 2,
        y = 2
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.jokercount + (#(G.jokers and G.jokers.cards or {})) * 1.5}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main then
                return {
                    xchips = card.ability.extra.jokercount + (#G.jokers.cards) * 1.5
                }
        end
    end
}