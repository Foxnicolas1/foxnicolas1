SMODS.Joker{ --rose
    name = "rose",
    key = "rose",
    config = {
        extra = {
            emult = 50
        }
    },
    loc_txt = {
        ['name'] = 'rose',
        ['text'] = {
            [1] = '{X:mult,C:white}^50{} Mult if you play your last hand'
        }
    },
    pos = {
        x = 4,
        y = 2
    },
    cost = 8,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    soul_pos = {
        x = 5,
        y = 2
    },

    loc_vars = function(self, info_queue, card)
        return {vars = {}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main then
            if G.GAME.current_round.hands_left == 0 then
                return {
                    e_mult = card.ability.extra.emult,
                    message = "..."
                }
            end
        end
    end
}