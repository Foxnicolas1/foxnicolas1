SMODS.Joker{ --HORROR wenda
    name = "HORROR wenda",
    key = "horrorwenda",
    config = {
        extra = {
            Xmult = 20,
            emult = 2
        }
    },
    loc_txt = {
        ['name'] = 'HORROR wenda',
        ['text'] = {
            [1] = 'gives {X:mult,C:white}x20{} Mult and {X:mult,C:white}^2{} Mult'
        }
    },
    pos = {
        x = 1,
        y = 2
    },
    cost = 8,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main then
                return {
                    Xmult = card.ability.extra.Xmult,
                    extra = {
                        e_mult = card.ability.extra.emult,
                        colour = G.C.DARK_EDITION
                        }
                }
        end
    end
}