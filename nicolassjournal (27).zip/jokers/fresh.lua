SMODS.Joker{ --Fresh
    name = "Fresh",
    key = "fresh",
    config = {
        extra = {
            fresh = 1
        }
    },
    loc_txt = {
        ['name'] = 'Fresh',
        ['text'] = {
            [1] = '"grants {X:blue,C:white}^0.03{} per reroll during this run"',
            [2] = '(currently {X:chips,C:white}^#1#{} Chips)'
        }
    },
    pos = {
        x = 7,
        y = 1
    },
    cost = 9,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    soul_pos = {
        x = 8,
        y = 1
    },

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.fresh}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main then
                return {
                    e_chips = card.ability.extra.fresh
                }
        end
        if context.reroll_shop and not context.blueprint then
                return {
                    func = function()
                    card.ability.extra.fresh = (card.ability.extra.fresh) + 0.03
                    return true
                end,
                    message = "cool man"
                }
        end
    end
}