SMODS.Joker{ --asa
    name = "asa",
    key = "asa",
    config = {
        extra = {
            otherjokerssellvalue = 0.1
        }
    },
    loc_txt = {
        ['name'] = 'asa',
        ['text'] = {
            [1] = 'grants {X:blue,C:white}Xchips{} for every sell value of every other jokers',
            [2] = '(currently {X:chips,C:white}x#1#{} Chips)'
        }
    },
    pos = {
        x = 2,
        y = 1
    },
    cost = 8,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    soul_pos = {
        x = 3,
        y = 1
    },

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.otherjokerssellvalue + ((function() local total = 0; for _, joker in ipairs((G.jokers and G.jokers.cards or {})) do if joker ~= card then total = total + joker.sell_cost end end; return total end)()) * 1.1}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main then
                return {
                    xchips = card.ability.extra.otherjokerssellvalue + ((function() local total = 0; for _, joker in ipairs(G.jokers.cards) do if joker ~= card then total = total + joker.sell_cost end end; return total end)()) * 1.1
                }
        end
    end
}