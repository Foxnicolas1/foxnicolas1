SMODS.Joker{ --mystery joker
    name = "mystery joker",
    key = "mysteryjoker",
    config = {
        extra = {
            odds = 4,
            chips_min = 10,
            chips_max = 5000,
            mult_min = 1,
            mult_max = 500
        }
    },
    loc_txt = {
        ['name'] = 'mystery joker',
        ['text'] = {
            [1] = '"something random happens when playing a hand"'
        }
    },
    pos = {
        x = 7,
        y = 0
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main then
            if true then
                if pseudorandom('group_0_ecb68fd4') < G.GAME.probabilities.normal / card.ability.extra.odds then
                        SMODS.calculate_effect({chips = pseudorandom('chips_3acebad2', card.ability.extra.chips_min, card.ability.extra.chips_max)}, card)
                    end
                if pseudorandom('group_1_4c5a0a49') < G.GAME.probabilities.normal / card.ability.extra.odds then
                        SMODS.calculate_effect({mult = pseudorandom('mult_acc1d4c1', card.ability.extra.mult_min, card.ability.extra.mult_max)}, card)
                    end
            end
        end
    end
}