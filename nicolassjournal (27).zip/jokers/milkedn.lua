SMODS.Joker{ --milked n
    name = "milked n",
    key = "milkedn",
    config = {
        extra = {
            lasting_for = 5,
            chips = 200,
            var1 = 0
        }
    },
    loc_txt = {
        ['name'] = 'milked n',
        ['text'] = {
            [1] = '"gives {C:blue}+200 chips{} when a hand is played.',
            [2] = 'will destroy itself when playing 5 hands, can extend when selling a {C:blue}sly joker{}{} (not yet)"'
        }
    },
    pos = {
        x = 3,
        y = 0
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main then
            if (card.ability.extra.lasting_for or 0) < 1 then
                return {
                    func = function()
                card:start_dissolve()
                return true
            end,
                    message = "Destroyed!"
                }
            else
                card.ability.extra.var1 = math.max(0, (card.ability.extra.var1) - 1)
                return {
                    chips = card.ability.extra.chips
                }
            end
        end
    end
}