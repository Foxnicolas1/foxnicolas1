SMODS.Joker{ --the apple
    name = "the apple",
    key = "theapple",
    config = {
        extra = {
            apple = 10
        }
    },
    loc_txt = {
        ['name'] = 'the apple',
        ['text'] = {
            [1] = '"sell this to gain {C:money}#1#${}. gain {C:money}1${} more if kept it with you"'
        }
    },
    pos = {
        x = 0,
        y = 1
    },
    cost = 10,
    rarity = 1,
    blueprint_compat = false,
    eternal_compat = false,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.apple}}
    end,

    calculate = function(self, card, context)
        if context.selling_self and not context.blueprint then
                return {
                    dollars = card.ability.extra.apple,
                    message = "genesis has blessed you"
                }
        end
        if context.end_of_round and context.game_over == false and context.main_eval and not context.blueprint then
                return {
                    func = function()
                    card.ability.extra.apple = (card.ability.extra.apple) + 1
                    return true
                end
                }
        end
    end
}