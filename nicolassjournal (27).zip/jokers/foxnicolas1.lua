SMODS.Joker{ --foxnicolas1
    name = "foxnicolas1",
    key = "foxnicolas1",
    config = {
        extra = {
            currentmoney = 1
        }
    },
    loc_txt = {
        ['name'] = 'foxnicolas1',
        ['text'] = {
            [1] = '"gain {X:mult,C:white}^mult{} depending on how much money you have"',
            [2] = '(currently {X:mult,C:white}^#1#{} mult)'
        }
    },
    pos = {
        x = 4,
        y = 0
    },
    cost = 10,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    soul_pos = {
        x = 5,
        y = 0
    },

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.currentmoney + ((G.GAME.dollars or 0)) * 0.01}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main then
                return {
                    e_mult = card.ability.extra.currentmoney + (G.GAME.dollars) * 0.01,
                    extra = {
                        message = "wealth is key to me",
                        colour = G.C.WHITE
                        }
                }
        end
    end
}