SMODS.Joker{ --silent
    name = "silent",
    key = "silent",
    config = {
        extra = {
            jokercount = 1
        }
    },
    loc_txt = {
        ['name'] = 'silent',
        ['text'] = {
            [1] = 'grants {X:mult,C:white}x1{} per joker you have',
            [2] = '(currently gives {X:mult,C:white}x#1#{} mult)'
        }
    },
    pos = {
        x = 3,
        y = 2
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.jokercount + (#(G.jokers and G.jokers.cards or {}))}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main then
                return {
                    Xmult = card.ability.extra.jokercount + (#G.jokers.cards)
                }
        end
    end
}