SMODS.Joker{ --N pile
    name = "N pile",
    key = "npile",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'N pile',
        ['text'] = {
            [1] = '"retriggers all jokers for every 10 sold {C:blue}sly jokers{}'
        }
    },
    pos = {
        x = 1,
        y = 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main then
                return {
                    message = "wont do anything yet..."
                }
        end
    end
}