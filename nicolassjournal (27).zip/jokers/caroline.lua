SMODS.Joker{ --caroline
    name = "caroline",
    key = "caroline",
    config = {
        extra = {
            caroline = 5
        }
    },
    loc_txt = {
        ['name'] = 'caroline',
        ['text'] = {
            [1] = 'when a hand is played, {C:red}+5{} Mult, Multiplies by 1.5 when a card is scored',
            [2] = '(currently {C:red}+#1#{} Mult)'
        }
    },
    pos = {
        x = 2,
        y = 3
    },
    cost = 8,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    soul_pos = {
        x = 3,
        y = 3
    },

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.caroline}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main then
                return {
                    mult = card.ability.extra.caroline
                }
        end
        if context.individual and context.cardarea == G.play and not context.blueprint then
                card.ability.extra.caroline = (card.ability.extra.caroline) * 1.5
        end
    end
}