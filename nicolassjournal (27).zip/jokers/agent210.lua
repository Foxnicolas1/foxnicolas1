SMODS.Joker{ --agent210
    name = "agent210",
    key = "agent210",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'agent210',
        ['text'] = {
            [1] = '"applies a random {C:edition}Edition{} to a random joker on round end"'
        }
    },
    pos = {
        x = 8,
        y = 0
    },
    cost = 8,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    soul_pos = {
        x = 9,
        y = 0
    },

    loc_vars = function(self, info_queue, card)
        return {vars = {}}
    end,

    calculate = function(self, card, context)
        if context.end_of_round and context.game_over == false and context.main_eval and not context.blueprint then
                return {
                    message = "nothing happens yet... friend"
                }
        end
    end
}