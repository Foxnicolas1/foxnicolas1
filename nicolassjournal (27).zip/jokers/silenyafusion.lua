SMODS.Joker{ --silenya (fusion)
    name = "silenya (fusion)",
    key = "silenyafusion",
    config = {
        extra = {
            jokercount = 0
        }
    },
    loc_txt = {
        ['name'] = 'silenya (fusion)',
        ['text'] = {
            [1] = 'grants {X:chips,C:white}x2{} Chips and {X:mult,C:white}x1.5{} Mult for every joker you have',
            [2] = '(currently gives {X:chips,C:white}x#1#{} Chips and {X:mult,C:white}x#1#{} Mult)'
        }
    },
    pos = {
        x = 8,
        y = 3
    },
    cost = 8,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {(#(G.jokers and G.jokers.cards or {})) * 2}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main then
                return {
                    xchips = (#G.jokers.cards) * 2,
                    extra = {
                        Xmult = (#G.jokers.cards) * 1.5
                        }
                }
        end
    end
}